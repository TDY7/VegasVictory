Teddy MASSARD--HYSON et Julie LANCON

BlackJack - VegasVictory
Le lien vers la vidéo : https://youtu.be/Bfa-mRgEOWs?si=eQ7IF4iwgqgY8A7A
(Nous avons utilisé XAMPP pour notre jeu)